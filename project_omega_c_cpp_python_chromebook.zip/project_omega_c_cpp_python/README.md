# Project Omega Central — SentinelOps AI
## C + C++ + Python Chromebook starter

This version intentionally uses all three requested languages:

- **C** (`src/event_validator.c`): validates supported event-type and severity fields. Python loads the compiled shared library through `ctypes`.
- **C++** (`src/risk_engine.cpp`): computes the base risk score and risk level as a small native executable.
- **Python** (`app.py`, `detector.py`): web dashboard, orchestration, response recommendations, and tests. Python gracefully falls back to its local scoring implementation if native binaries have not been built.

## Build and run on ChromeOS

1. Enable **Linux development environment** in ChromeOS settings if your device supports it.
2. Extract the project and open Terminal in the project directory.
3. Install build tools and Python dependencies:

```bash
sudo apt update
sudo apt install -y build-essential python3 python3-venv python3-pip
make
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m unittest -v
python app.py
```

4. In Chrome, open `http://127.0.0.1:5000`.
5. Stop the local server with `Ctrl+C`.

If `make` is unavailable, compile manually:

```bash
mkdir -p build
gcc -O2 -Wall -Wextra -Werror -fPIC -shared src/event_validator.c -o build/libevent_validator.so
g++ -O2 -Wall -Wextra -Werror -std=c++17 src/risk_engine.cpp -o build/risk_engine
```

## IBM Bob + Gemini workflow

1. Open the extracted folder in IBM Bob if your environment supports project-file access.
2. Ask Bob to inspect the C, C++, and Python boundaries before changing them.
3. Use Gemini as an independent reviewer for the native code, validation, scoring, and tests.
4. Bring review findings back to Bob, implement justified fixes, and rerun `make test`.

## Safety and scope

- This is a prototype, not a production security platform.
- Risk scores are illustrative heuristics, not validated threat predictions.
- No real infrastructure is monitored, blocked, isolated, or remediated.
- Use synthetic demo data only. Never enter passwords, tokens, or API keys into event details.
- Do not connect real security systems until authentication, authorization, logging, secure configuration, and an appropriate test plan are in place.
