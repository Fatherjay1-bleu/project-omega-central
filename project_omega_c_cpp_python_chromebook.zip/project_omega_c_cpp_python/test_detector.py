import unittest
from detector import analyze_event

class DetectorTests(unittest.TestCase):
    def test_critical_privilege_change_scores_critical(self):
        result = analyze_event({"event_type":"privilege_change","severity":"critical","source":"test"})
        self.assertEqual(result["risk_level"], "Critical")
        self.assertGreaterEqual(result["score"], 85)

    def test_low_successful_login_is_low(self):
        result = analyze_event({"event_type":"successful_login","severity":"low","source":"test"})
        self.assertEqual(result["risk_level"], "Low")
        self.assertEqual(result["score"], 8)

    def test_high_findings_include_escalation(self):
        result = analyze_event({"event_type":"malware_alert","severity":"high","source":"test"})
        self.assertIn("Escalate to the security analyst or incident commander according to policy.", result["actions"])

    def test_unknown_input_is_normalized(self):
        result = analyze_event({"event_type":"not_real","severity":"wild","source":"test"})
        self.assertEqual(result["event_type"], "unknown")
        self.assertEqual(result["risk_level"], "Medium")

if __name__ == "__main__":
    unittest.main()
