from flask import Flask, render_template_string, request
from datetime import datetime, timezone
from detector import analyze_event, SAMPLE_EVENTS

app = Flask(__name__)

PAGE = """
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Project Omega | SentinelOps AI</title>
<style>
:root{font-family:Inter,system-ui,Arial,sans-serif;color:#e9eef8;background:#0b1220}
body{margin:0}.wrap{max-width:1100px;margin:auto;padding:28px}
header{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}
.eyebrow{color:#78a9ff;text-transform:uppercase;letter-spacing:.12em;font-size:.75rem;font-weight:700}
h1{margin:.3rem 0;font-size:2rem}.muted{color:#a8b4c8}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin:22px 0}
.card{background:#121d30;border:1px solid #263750;border-radius:16px;padding:18px}
.metric{font-size:1.8rem;font-weight:800;margin-top:8px}
form{display:grid;gap:10px}label{font-size:.9rem;color:#cbd5e1}
input,select,textarea{box-sizing:border-box;width:100%;padding:11px;border-radius:9px;border:1px solid #344660;background:#0b1526;color:#eef4ff}
textarea{min-height:90px;resize:vertical}
button{padding:11px 15px;border:0;border-radius:9px;background:#4f8cff;color:white;font-weight:700;cursor:pointer}
button.secondary{background:#263750}.event{border-top:1px solid #263750;padding:14px 0}
.pill{display:inline-block;padding:4px 8px;border-radius:999px;font-size:.78rem;font-weight:700}
.Low{background:#164e3c;color:#9af0c5}.Medium{background:#59400c;color:#ffdf8a}.High{background:#65262b;color:#ffb5bb}.Critical{background:#871e35;color:#fff}
.two{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px}
small{color:#8da0ba}.footer{margin-top:26px;font-size:.8rem;color:#8da0ba}
</style>
</head>
<body><div class="wrap">
<header><div><div class="eyebrow">Project Omega Central</div><h1>SentinelOps AI</h1><div class="muted">Security event triage • Prototype dashboard</div></div><div class="pill Medium">DEMO MODE · SIMULATED DATA</div></header>
<div class="grid">
<div class="card"><div class="muted">Events analyzed</div><div class="metric">{{ results|length }}</div></div>
<div class="card"><div class="muted">High / critical findings</div><div class="metric">{{ high_count }}</div></div>
<div class="card"><div class="muted">Analysis timestamp</div><div style="margin-top:8px">{{ timestamp }}</div></div>
</div>
<div class="two">
<section class="card"><h2>Analyze an event</h2>
<form method="post">
<label>Event type<select name="event_type">
<option>failed_login</option><option>successful_login</option><option>privilege_change</option><option>malware_alert</option><option>unusual_network_traffic</option><option>unknown</option>
</select></label>
<label>Severity reported<select name="severity"><option>low</option><option selected>medium</option><option>high</option><option>critical</option></select></label>
<label>Source IP or host<input name="source" placeholder="e.g. 203.0.113.42 or workstation-07"></label>
<label>Event details<textarea name="details" placeholder="Describe what happened. Do not enter real credentials or sensitive personal data."></textarea></label>
<button type="submit">Analyze event</button>
</form></section>
<section class="card"><h2>How this prototype works</h2>
<p class="muted">Rule-based triage converts event fields into a transparent risk score and suggested next steps. It does not connect to real infrastructure or take actions on systems.</p>
<ul><li>Explainable risk scoring</li><li>Recommended response checklist</li><li>Sample events for a repeatable demo</li><li>Unit tests for core detection rules</li></ul>
<form method="post" action="/load-samples"><button class="secondary" type="submit">Load sample events</button></form>
</section>
</div>
<section class="card" style="margin-top:14px"><h2>Event triage results</h2>
{% if not results %}<p class="muted">No events yet. Analyze an event or load the sample set.</p>{% endif %}
{% for r in results %}
<div class="event"><div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap"><strong>{{ r.title }}</strong><span class="pill {{ r.risk_level }}">{{ r.risk_level }} · {{ r.score }}/100</span></div>
<p class="muted">{{ r.summary }}</p><small>Source: {{ r.source }} · Type: {{ r.event_type }}</small>
<h4>Recommended actions</h4><ul>{% for action in r.actions %}<li>{{ action }}</li>{% endfor %}</ul></div>
{% endfor %}
</section>
<div class="footer">Prototype only. Use synthetic data. Validate findings with qualified security personnel before taking action. No automated blocking or remediation is enabled.</div>
</div></body></html>
"""

results = []

@app.get("/")
def home():
    return render_page()

@app.post("/")
def analyze():
    event = {
        "event_type": request.form.get("event_type", "unknown"),
        "severity": request.form.get("severity", "medium"),
        "source": request.form.get("source", "").strip() or "unspecified",
        "details": request.form.get("details", "").strip()
    }
    results.insert(0, analyze_event(event))
    del results[20:]
    return render_page()

@app.post("/load-samples")
def load_samples():
    results[:] = [analyze_event(e) for e in SAMPLE_EVENTS]
    return render_page()

def render_page():
    high_count = sum(1 for r in results if r["risk_level"] in ("High", "Critical"))
    return render_template_string(PAGE, results=results, high_count=high_count,
        timestamp=datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"))

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
