#include <stddef.h>
#include <string.h>

/* Small C validation helper exposed for Python ctypes integration.
   Returns 1 when both fields are recognized, otherwise 0. */
int validate_event_fields(const char *event_type, const char *severity) {
    const char *types[] = {
        "failed_login", "successful_login", "privilege_change",
        "malware_alert", "unusual_network_traffic", "unknown"
    };
    const char *severities[] = {"low", "medium", "high", "critical"};
    size_t i;
    int type_ok = 0, severity_ok = 0;

    if (event_type == NULL || severity == NULL) return 0;
    for (i = 0; i < sizeof(types) / sizeof(types[0]); ++i) {
        if (strcmp(event_type, types[i]) == 0) { type_ok = 1; break; }
    }
    for (i = 0; i < sizeof(severities) / sizeof(severities[0]); ++i) {
        if (strcmp(severity, severities[i]) == 0) { severity_ok = 1; break; }
    }
    return type_ok && severity_ok;
}
