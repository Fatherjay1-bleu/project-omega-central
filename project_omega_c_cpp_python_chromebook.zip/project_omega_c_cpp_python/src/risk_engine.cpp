#include <algorithm>
#include <iostream>
#include <map>
#include <string>

/* Usage: ./risk_engine <event_type> <severity>
   Prints: score|risk_level
   This native engine intentionally has a tiny stable CLI contract. */
int main(int argc, char** argv) {
    if (argc != 3) {
        std::cerr << "Usage: risk_engine <event_type> <severity>\n";
        return 2;
    }
    const std::string type = argv[1];
    const std::string severity = argv[2];

    const std::map<std::string, int> base = {
        {"low", 10}, {"medium", 30}, {"high", 55}, {"critical", 75}
    };
    const std::map<std::string, int> bonus = {
        {"failed_login", 15}, {"successful_login", 0},
        {"privilege_change", 20}, {"malware_alert", 25},
        {"unusual_network_traffic", 15}, {"unknown", 5}
    };

    auto b = base.find(severity);
    auto x = bonus.find(type);
    if (b == base.end() || x == bonus.end()) {
        std::cerr << "Unsupported event type or severity\n";
        return 3;
    }

    int score = std::min(100, b->second + x->second);
    if (type == "successful_login" && severity == "low") score = 8;

    std::string level = "Low";
    if (score >= 85) level = "Critical";
    else if (score >= 60) level = "High";
    else if (score >= 30) level = "Medium";

    std::cout << score << "|" << level << "\n";
    return 0;
}
