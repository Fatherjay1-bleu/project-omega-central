"""SentinelOps triage orchestration with C validation and C++ scoring when built."""
import ctypes
import os
import subprocess

ROOT = os.path.dirname(os.path.abspath(__file__))
VALIDATOR_PATH = os.path.join(ROOT, "build", "libevent_validator.so")
ENGINE_PATH = os.path.join(ROOT, "build", "risk_engine")

SAMPLE_EVENTS = [
    {"event_type": "failed_login", "severity": "high", "source": "203.0.113.42",
     "details": "Repeated failed sign-ins for several user accounts in a short window."},
    {"event_type": "privilege_change", "severity": "critical", "source": "admin-console-01",
     "details": "Unexpected privilege elevation outside the normal maintenance window."},
    {"event_type": "successful_login", "severity": "low", "source": "workstation-07",
     "details": "Routine sign-in from a known device during business hours."},
    {"event_type": "malware_alert", "severity": "high", "source": "endpoint-12",
     "details": "Endpoint protection raised a malware detection alert."},
]

BASE = {"low": 10, "medium": 30, "high": 55, "critical": 75}
BONUS = {"failed_login": 15, "successful_login": 0, "privilege_change": 20,
         "malware_alert": 25, "unusual_network_traffic": 15, "unknown": 5}
VALID_TYPES = set(BONUS)
VALID_SEVERITIES = set(BASE)

def _c_validate(event_type, severity):
    if not os.path.exists(VALIDATOR_PATH):
        return event_type in VALID_TYPES and severity in VALID_SEVERITIES
    try:
        lib = ctypes.CDLL(VALIDATOR_PATH)
        fn = lib.validate_event_fields
        fn.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
        fn.restype = ctypes.c_int
        return bool(fn(event_type.encode("utf-8"), severity.encode("utf-8")))
    except (OSError, AttributeError):
        return event_type in VALID_TYPES and severity in VALID_SEVERITIES

def _score(event_type, severity):
    if os.path.exists(ENGINE_PATH):
        try:
            proc = subprocess.run(
                [ENGINE_PATH, event_type, severity],
                check=True, capture_output=True, text=True, timeout=2
            )
            score_text, level = proc.stdout.strip().split("|", 1)
            return int(score_text), level
        except (OSError, subprocess.SubprocessError, ValueError):
            pass
    score = min(100, BASE[severity] + BONUS[event_type])
    if event_type == "successful_login" and severity == "low":
        score = 8
    level = "Critical" if score >= 85 else "High" if score >= 60 else "Medium" if score >= 30 else "Low"
    return score, level

def analyze_event(event):
    event_type = str(event.get("event_type", "unknown")).lower().strip()
    severity = str(event.get("severity", "medium")).lower().strip()
    source = str(event.get("source", "unspecified"))[:160]
    details = str(event.get("details", "")).strip()[:2000]

    if not _c_validate(event_type, severity):
        event_type, severity = "unknown", "medium"

    score, level = _score(event_type, severity)
    actions = recommendations(event_type, level)
    readable = event_type.replace("_", " ").title()
    return {"title": readable, "event_type": event_type, "source": source,
            "score": score, "risk_level": level,
            "summary": details or f"{readable} event received with reported severity {severity}.",
            "actions": actions}

def recommendations(event_type, level):
    actions = ["Preserve the event record and correlate it with relevant logs."]
    if event_type == "failed_login":
        actions += ["Check frequency, affected accounts, source reputation, and MFA outcomes.",
                    "Follow your approved account-protection procedure if activity is confirmed malicious."]
    elif event_type == "privilege_change":
        actions += ["Verify the change with the authorized system owner.",
                    "Review administrator audit logs and the change-management record."]
    elif event_type == "malware_alert":
        actions += ["Review endpoint security telemetry and validate the detection.",
                    "Follow the organization's approved containment process if confirmed."]
    elif event_type == "unusual_network_traffic":
        actions += ["Compare destination, volume, timing, and protocol with the known baseline.",
                    "Correlate with DNS, firewall, endpoint, and identity events."]
    elif event_type == "successful_login":
        actions += ["Check whether the device, location, and time match the user's normal pattern."]
    else:
        actions += ["Enrich the event with timestamp, asset identity, user context, and related telemetry."]
    if level in ("High", "Critical"):
        actions.append("Escalate to the security analyst or incident commander according to policy.")
    return actions
